package com.armando.SoloProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoloAirlineProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
