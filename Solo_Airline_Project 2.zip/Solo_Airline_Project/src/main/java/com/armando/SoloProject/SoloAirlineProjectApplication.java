package com.armando.SoloProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoloAirlineProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoloAirlineProjectApplication.class, args);
	}

}
